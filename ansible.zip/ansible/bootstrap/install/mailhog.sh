##Install Mailhog
cp /vagrant/files/install/Mailhog_linux_amd64 /home/vagrant/Mailhog_linux_amd64
cd /home/vagrant/
sudo ./Mailhog_linux_amd64 &