clear
clear
rm -r ./*
sudo cp -a /vagrant/files/etc/ansible/. /etc/ansible/
